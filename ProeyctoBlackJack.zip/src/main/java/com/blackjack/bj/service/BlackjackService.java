// BlackjackService.java - Versión corregida
package com.blackjack.bj.service;

import com.blackjack.bj.exception.BarajaVaciaException;
import com.blackjack.bj.exception.JuegoException;
import com.blackjack.bj.exception.SaldoInsuficienteException;
import com.blackjack.bj.model.*;
import java.util.logging.Logger;

public class BlackjackService implements IBlackjackService {
    private static final Logger LOGGER = Logger.getLogger(BlackjackService.class.getName());

    private final Jugador jugador;
    private final Dealer dealer;
    private final Baraja baraja;
    private final IBaseDatosService baseDatosService;
    private EstadoJuego estadoJuego;

    public BlackjackService(Jugador jugador, IBaseDatosService baseDatosService) {
        this.jugador = jugador;
        this.dealer = new Dealer();
        this.baraja = new Baraja();
        this.baseDatosService = baseDatosService;
        this.estadoJuego = EstadoJuego.ESPERANDO_APUESTA;

        baraja.mezclar();
    }

    @Override
    public void iniciarNuevoJuego() throws JuegoException {
        try {
            // *** CORRECCIÓN BUG 1: Limpiar completamente el estado anterior ***
            dealer.reiniciar();
            jugador.reiniciarManos(); // Esto debería limpiar todas las manos

            // *** VERIFICACIÓN ADICIONAL: Asegurar que las manos estén completamente limpias ***
            if (jugador.getManoActiva().cantidadCartas() > 0) {
                LOGGER.warning("⚠️ Las manos no se limpiaron correctamente. Forzando limpieza...");
                jugador.getManoActiva().limpiar();
            }

            // Verificar si necesitamos una nueva baraja
            if (baraja.cartasRestantes() < 20) {
                baraja.resetear();
                LOGGER.info("🔄 Baraja reiniciada - cartas restantes eran: " + baraja.cartasRestantes());
            }

            estadoJuego = EstadoJuego.ESPERANDO_APUESTA;
            LOGGER.info("🎮 Nuevo juego iniciado - Manos limpiadas correctamente");

        } catch (Exception e) {
            throw new JuegoException("Error al iniciar nuevo juego: " + e.getMessage());
        }
    }

    @Override
    public void realizarApuesta(double cantidad) throws SaldoInsuficienteException, JuegoException {
        if (estadoJuego != EstadoJuego.ESPERANDO_APUESTA) {
            throw new JuegoException("No se puede apostar en este momento");
        }

        // *** VERIFICACIÓN ADICIONAL: Asegurar que las manos estén limpias antes de apostar ***
        if (jugador.getManoActiva().cantidadCartas() > 0) {
            LOGGER.warning("⚠️ Detectadas cartas residuales antes de apostar. Limpiando...");
            jugador.reiniciarManos();
        }

        try {
            jugador.apostar(cantidad);
            estadoJuego = EstadoJuego.REPARTIENDO;
            repartirCartasIniciales();
            LOGGER.info(String.format("💰 Apuesta realizada: $%.2f", cantidad));
        } catch (BarajaVaciaException e) {
            throw new JuegoException("No hay suficientes cartas para jugar");
        }
    }

    private void repartirCartasIniciales() throws BarajaVaciaException {
        // *** VERIFICACIÓN FINAL: Confirmar que las manos estén vacías antes de repartir ***
        if (jugador.getManoActiva().cantidadCartas() != 0 || dealer.getMano().cantidadCartas() != 0) {
            LOGGER.severe("🚨 ERROR: Intentando repartir cartas cuando las manos no están vacías!");
            dealer.reiniciar();
            jugador.reiniciarManos();
        }

        // Repartir 2 cartas al jugador y 2 al dealer
        jugador.getManoActiva().agregarCarta(baraja.repartirCarta());
        dealer.agregarCarta(baraja.repartirCarta());
        jugador.getManoActiva().agregarCarta(baraja.repartirCarta());
        dealer.agregarCarta(baraja.repartirCarta());

        LOGGER.info("🃏 Cartas repartidas - Jugador: " + jugador.getManoActiva().cantidadCartas() +
                " cartas, Dealer: " + dealer.getMano().cantidadCartas() + " cartas");

        // Cambiar al turno del jugador
        estadoJuego = EstadoJuego.TURNO_JUGADOR;

        // Verificar blackjack natural
        if (jugador.getManoActiva().esBlackjack()) {
            if (dealer.getMano().esBlackjack()) {
                // Ambos tienen blackjack - empate
                finalizarJuegoConResultado(ResultadoMano.EMPATE);
            } else {
                // Solo el jugador tiene blackjack
                finalizarJuegoConResultado(ResultadoMano.BLACKJACK_JUGADOR);
            }
        } else if (dealer.getMano().esBlackjack()) {
            // Solo el dealer tiene blackjack
            finalizarJuegoConResultado(ResultadoMano.BLACKJACK_DEALER);
        }
    }

    @Override
    public void realizarAccion(AccionJuego accion) throws JuegoException {
        if (estadoJuego != EstadoJuego.TURNO_JUGADOR) {
            throw new JuegoException("No es el turno del jugador");
        }

        if (!puedeRealizarAccion(accion)) {
            throw new JuegoException("Acción no permitida en este momento");
        }

        try {
            switch (accion) {
                case PEDIR_CARTA:
                    pedirCarta();
                    break;
                case PLANTARSE:
                    plantarse();
                    break;
                case DOBLAR:
                    doblar();
                    break;
                case DIVIDIR:
                    dividir();
                    break;
                case RENDIRSE:
                    rendirse();
                    break;
                default:
                    throw new JuegoException("Acción no reconocida");
            }
        } catch (BarajaVaciaException e) {
            throw new JuegoException("No hay más cartas disponibles");
        } catch (SaldoInsuficienteException e) {
            throw new JuegoException("Saldo insuficiente para esta acción");
        }
    }

    private void pedirCarta() throws BarajaVaciaException, JuegoException {
        Mano manoActiva = jugador.getManoActiva();
        manoActiva.agregarCarta(baraja.repartirCarta());

        LOGGER.info("🃏 Carta pedida - Total cartas jugador: " + manoActiva.cantidadCartas() +
                ", Valor: " + manoActiva.getValor());

        if (manoActiva.estaPasado()) {
            if (jugador.tieneMasManos()) {
                jugador.siguienteMano();
            } else {
                finalizarJuegoConResultado(ResultadoMano.JUGADOR_SE_PASA);
            }
        }
    }

    private void plantarse() {
        LOGGER.info("✋ Jugador se plantó");
        if (jugador.tieneMasManos()) {
            jugador.siguienteMano();
        } else {
            estadoJuego = EstadoJuego.TURNO_DEALER;
        }
    }

    private void doblar() throws SaldoInsuficienteException, BarajaVaciaException, JuegoException {
        double apuestaActual = jugador.getApuestaActiva();
        jugador.apostar(apuestaActual); // Doblar la apuesta

        // Tomar exactamente una carta más
        jugador.getManoActiva().agregarCarta(baraja.repartirCarta());

        LOGGER.info("💰 Apuesta doblada - Nueva apuesta: $" + (apuestaActual * 2));

        // Después de doblar, automáticamente se planta
        if (jugador.tieneMasManos()) {
            jugador.siguienteMano();
        } else {
            estadoJuego = EstadoJuego.TURNO_DEALER;
        }
    }

    private void dividir() throws SaldoInsuficienteException, BarajaVaciaException {
        jugador.partirMano();

        // Agregar una carta a cada mano dividida
        jugador.getManoActiva().agregarCarta(baraja.repartirCarta());
        // La siguiente mano también necesita una carta
        if (jugador.getManos().size() > jugador.getManoActivaIndex() + 1) {
            jugador.getManos().get(jugador.getManoActivaIndex() + 1).agregarCarta(baraja.repartirCarta());
        }

        LOGGER.info("✂️ Mano dividida - Total manos: " + jugador.getManos().size());
    }

    private void rendirse() {
        // El jugador recupera la mitad de su apuesta
        double apuesta = jugador.getApuestaActiva();
        jugador.ganar(apuesta / 2);
        LOGGER.info("🏳️ Jugador se rindió - Recupera: $" + (apuesta / 2));
        finalizarJuegoConResultado(ResultadoMano.DEALER_GANA);
    }

    @Override
    public void procesarTurnoDealer() throws JuegoException {
        if (estadoJuego != EstadoJuego.TURNO_DEALER) {
            throw new JuegoException("No es el turno del dealer");
        }

        try {
            dealer.mostrarCartaOculta();

            while (dealer.debeTomarCarta()) {
                dealer.agregarCarta(baraja.repartirCarta());
            }

            LOGGER.info("🤵 Dealer terminó - Valor final: " + dealer.getMano().getValor());

            // Evaluar resultados para cada mano del jugador
            for (int i = 0; i < jugador.getManos().size(); i++) {
                Mano manoJugador = jugador.getManos().get(i);
                ResultadoMano resultado = evaluarMano(manoJugador);
                procesarResultado(resultado, i);
            }

            estadoJuego = EstadoJuego.JUEGO_TERMINADO;

        } catch (BarajaVaciaException e) {
            throw new JuegoException("No hay más cartas para el dealer");
        }
    }

    @Override
    public ResultadoMano evaluarMano(Mano manoJugador) {
        int valorJugador = manoJugador.getValor();
        int valorDealer = dealer.getMano().getValor();

        if (manoJugador.estaPasado()) {
            return ResultadoMano.JUGADOR_SE_PASA;
        }

        if (dealer.getMano().estaPasado()) {
            return ResultadoMano.DEALER_SE_PASA;
        }

        if (valorJugador > valorDealer) {
            return ResultadoMano.JUGADOR_GANA;
        } else if (valorDealer > valorJugador) {
            return ResultadoMano.DEALER_GANA;
        } else {
            return ResultadoMano.EMPATE;
        }
    }

    private void procesarResultado(ResultadoMano resultado, int indiceApuesta) {
        double apuesta = jugador.getApuestas().get(indiceApuesta);
        double ganancia = 0;
        boolean gano = false;

        switch (resultado) {
            case JUGADOR_GANA:
            case DEALER_SE_PASA:
                ganancia = apuesta * 2; // Devolver apuesta + ganancia
                gano = true;
                break;
            case BLACKJACK_JUGADOR:
                ganancia = apuesta * 2.5; // Pago 3:2 para blackjack
                gano = true;
                break;
            case EMPATE:
                ganancia = apuesta; // Solo devolver la apuesta
                break;
            case DEALER_GANA:
            case BLACKJACK_DEALER:
            case JUGADOR_SE_PASA:
                ganancia = 0; // Se pierde la apuesta
                break;
        }

        if (ganancia > 0) {
            jugador.ganar(ganancia);
        }

        // Guardar estadística
        try {
            baseDatosService.guardarEstadistica("Blackjack", gano, apuesta, ganancia - apuesta);
            baseDatosService.actualizarSaldo(jugador.getSaldo());
        } catch (Exception e) {
            LOGGER.warning("Error al guardar estadísticas: " + e.getMessage());
        }
    }

    private void finalizarJuegoConResultado(ResultadoMano resultado) {
        procesarResultado(resultado, 0);
        estadoJuego = EstadoJuego.JUEGO_TERMINADO;
    }

    @Override
    public void finalizarJuego() {
        estadoJuego = EstadoJuego.ESPERANDO_APUESTA;

        // *** CORRECCIÓN BUG 1: Asegurar que se limpien las manos al finalizar ***
        LOGGER.info("🎯 Finalizando juego - Preparando para siguiente ronda");
    }

    @Override
    public boolean puedeRealizarAccion(AccionJuego accion) {
        if (estadoJuego != EstadoJuego.TURNO_JUGADOR) {
            return false;
        }

        Mano manoActiva = jugador.getManoActiva();

        switch (accion) {
            case PEDIR_CARTA:
            case PLANTARSE:
                return !manoActiva.estaPasado();

            case DOBLAR:
                return manoActiva.cantidadCartas() == 2 &&
                        jugador.getSaldo() >= jugador.getApuestaActiva();

            case DIVIDIR:
                return manoActiva.puedePartir() &&
                        jugador.getSaldo() >= jugador.getApuestaActiva() &&
                        jugador.getManos().size() < 4; // Límite de divisiones

            case RENDIRSE:
                return manoActiva.cantidadCartas() == 2 &&
                        jugador.getManos().size() == 1;

            default:
                return false;
        }
    }

    // Getters
    @Override
    public Jugador getJugador() {
        return jugador;
    }

    @Override
    public Dealer getDealer() {
        return dealer;
    }

    @Override
    public EstadoJuego getEstadoJuego() {
        return estadoJuego;
    }
}