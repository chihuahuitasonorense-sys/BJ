// IBlackjackService.java
package com.blackjack.bj.service;

import com.blackjack.bj.exception.JuegoException;
import com.blackjack.bj.exception.SaldoInsuficienteException;
import com.blackjack.bj.model.*;

public interface IBlackjackService {
    void iniciarNuevoJuego() throws JuegoException;
    void realizarApuesta(double cantidad) throws SaldoInsuficienteException, JuegoException;
    void realizarAccion(AccionJuego accion) throws JuegoException;
    void procesarTurnoDealer() throws JuegoException;
    void finalizarJuego();

    // Getters para el estado del juego
    Jugador getJugador();
    Dealer getDealer();
    EstadoJuego getEstadoJuego();
    boolean puedeRealizarAccion(AccionJuego accion);
    ResultadoMano evaluarMano(Mano manoJugador);
}