// BaseDatosService.java - Versión corregida para estadísticas
package com.blackjack.bj.service;

import com.blackjack.bj.exception.BaseDatosException;
import com.blackjack.bj.model.EstadisticasJugador;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BaseDatosService implements IBaseDatosService {
    private static final Logger LOGGER = Logger.getLogger(BaseDatosService.class.getName());
    private static final String DB_URL = "jdbc:sqlite:blackjack.db";
    private static final double SALDO_INICIAL = 1000.0;

    private Connection conexion;

    public BaseDatosService() {
        try {
            Class.forName("org.sqlite.JDBC");
            inicializar();
        } catch (ClassNotFoundException e) {
            LOGGER.log(Level.SEVERE, "Driver SQLite no encontrado", e);
            throw new RuntimeException("Driver SQLite no encontrado. Verifique que sqlite-jdbc esté en el classpath", e);
        } catch (BaseDatosException e) {
            LOGGER.log(Level.SEVERE, "Error al inicializar la base de datos", e);
            throw new RuntimeException("No se pudo inicializar la base de datos", e);
        }
    }

    @Override
    public void inicializar() throws BaseDatosException {
        try {
            LOGGER.info("Intentando conectar a base de datos SQLite...");

            String urlCompleta = DB_URL + "?journal_mode=WAL&synchronous=NORMAL";
            conexion = DriverManager.getConnection(urlCompleta);
            conexion.setAutoCommit(true);

            LOGGER.info("Conexión establecida exitosamente");

            crearTablas();
            migrarDatosExistentes();
            LOGGER.info("Base de datos inicializada correctamente");
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error SQL al inicializar la base de datos", e);
            throw new BaseDatosException("Error al inicializar la base de datos: " + e.getMessage(), e);
        }
    }

    private void crearTablas() throws SQLException {
        // Tabla de jugadores (nueva)
        String crearTablaJugadores = """
            CREATE TABLE IF NOT EXISTS jugadores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                partidas_jugadas INTEGER DEFAULT 0,
                partidas_ganadas INTEGER DEFAULT 0,
                partidas_perdidas INTEGER DEFAULT 0,
                partidas_empatadas INTEGER DEFAULT 0,
                partidas_rendidas INTEGER DEFAULT 0,
                maximo_dinero_obtenido REAL DEFAULT 1000.0,
                dinero_actual REAL DEFAULT 1000.0,
                fecha_creacion TEXT NOT NULL,
                fecha_ultima_partida TEXT,
                es_jugador_actual BOOLEAN DEFAULT 0
            )
        """;

        // Tabla de saldo (mantener para compatibilidad)
        String crearTablaSaldo = """
            CREATE TABLE IF NOT EXISTS saldo (
                id INTEGER PRIMARY KEY,
                cantidad REAL NOT NULL,
                fecha_actualizacion TEXT NOT NULL
            )
        """;

        // Tabla de estadísticas detalladas (mejorada)
        String crearTablaEstadisticas = """
            CREATE TABLE IF NOT EXISTS estadisticas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                jugador_id INTEGER,
                fecha TEXT NOT NULL,
                tipo_juego TEXT NOT NULL,
                gano BOOLEAN NOT NULL,
                apuesta REAL NOT NULL,
                ganancia REAL NOT NULL,
                tipo_resultado TEXT,
                FOREIGN KEY (jugador_id) REFERENCES jugadores (id)
            )
        """;

        try (Statement stmt = conexion.createStatement()) {
            stmt.execute(crearTablaJugadores);
            stmt.execute(crearTablaSaldo);
            stmt.execute(crearTablaEstadisticas);
            LOGGER.info("Tablas creadas/verificadas exitosamente");
        }
    }

    private void migrarDatosExistentes() throws SQLException, BaseDatosException {
        // Si existe saldo pero no hay jugador actual, crear uno por defecto
        if (!existeJugadorActual() && existeSaldoAnterior()) {
            try {
                double saldoAnterior = obtenerSaldoAnterior();
                EstadisticasJugador jugadorDefault = crearJugador("Jugador");
                jugadorDefault.setDineroActual(saldoAnterior);
                jugadorDefault.setMaximoDineroObtenido(Math.max(saldoAnterior, 1000.0));
                actualizarJugador(jugadorDefault);
                LOGGER.info("Migración completada: saldo anterior preservado");
            } catch (BaseDatosException e) {
                LOGGER.warning("Error en migración: " + e.getMessage());
            }
        }
    }

    private boolean existeSaldoAnterior() throws SQLException {
        String consulta = "SELECT COUNT(*) FROM saldo WHERE id = 1";
        try (Statement stmt = conexion.createStatement();
             ResultSet rs = stmt.executeQuery(consulta)) {
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    private double obtenerSaldoAnterior() throws SQLException {
        String consulta = "SELECT cantidad FROM saldo WHERE id = 1";
        try (Statement stmt = conexion.createStatement();
             ResultSet rs = stmt.executeQuery(consulta)) {
            if (rs.next()) {
                return rs.getDouble("cantidad");
            }
        }
        return SALDO_INICIAL;
    }

    @Override
    public EstadisticasJugador crearJugador(String nombre) throws BaseDatosException {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new BaseDatosException("El nombre del jugador no puede estar vacío");
        }

        // Limpiar jugador actual anterior
        eliminarJugadorActual();

        String insertar = """
            INSERT INTO jugadores (nombre, partidas_jugadas, partidas_ganadas, partidas_perdidas, 
                                 partidas_empatadas, partidas_rendidas, maximo_dinero_obtenido, 
                                 dinero_actual, fecha_creacion, es_jugador_actual) 
            VALUES (?, 0, 0, 0, 0, 0, ?, ?, ?, 1)
        """;

        try (PreparedStatement pstmt = conexion.prepareStatement(insertar)) {
            pstmt.setString(1, nombre.trim());
            pstmt.setDouble(2, SALDO_INICIAL);
            pstmt.setDouble(3, SALDO_INICIAL);
            pstmt.setString(4, LocalDateTime.now().toString());
            pstmt.executeUpdate();

            LOGGER.info("✅ Nuevo jugador creado: " + nombre);
            return new EstadisticasJugador(nombre.trim());
        } catch (SQLException e) {
            throw new BaseDatosException("Error al crear jugador", e);
        }
    }

    @Override
    public EstadisticasJugador obtenerJugadorActual() throws BaseDatosException {
        String consulta = """
            SELECT nombre, partidas_jugadas, partidas_ganadas, partidas_perdidas, 
                   partidas_empatadas, partidas_rendidas, maximo_dinero_obtenido, dinero_actual
            FROM jugadores WHERE es_jugador_actual = 1 LIMIT 1
        """;

        try (PreparedStatement pstmt = conexion.prepareStatement(consulta);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                return new EstadisticasJugador(
                        rs.getString("nombre"),
                        rs.getInt("partidas_jugadas"),
                        rs.getInt("partidas_ganadas"),
                        rs.getInt("partidas_perdidas"),
                        rs.getInt("partidas_empatadas"),
                        rs.getInt("partidas_rendidas"),
                        rs.getDouble("maximo_dinero_obtenido"),
                        rs.getDouble("dinero_actual")
                );
            } else {
                throw new BaseDatosException("No hay jugador actual");
            }
        } catch (SQLException e) {
            throw new BaseDatosException("Error al obtener jugador actual", e);
        }
    }

    @Override
    public void actualizarJugador(EstadisticasJugador jugador) throws BaseDatosException {
        String actualizar = """
            UPDATE jugadores SET 
                partidas_jugadas = ?, partidas_ganadas = ?, partidas_perdidas = ?,
                partidas_empatadas = ?, partidas_rendidas = ?, maximo_dinero_obtenido = ?,
                dinero_actual = ?, fecha_ultima_partida = ?
            WHERE es_jugador_actual = 1
        """;

        try (PreparedStatement pstmt = conexion.prepareStatement(actualizar)) {
            pstmt.setInt(1, jugador.getPartidasJugadas());
            pstmt.setInt(2, jugador.getPartidasGanadas());
            pstmt.setInt(3, jugador.getPartidasPerdidas());
            pstmt.setInt(4, jugador.getPartidasEmpatadas());
            pstmt.setInt(5, jugador.getPartidasRendidas());
            pstmt.setDouble(6, jugador.getMaximoDineroObtenido());
            pstmt.setDouble(7, jugador.getDineroActual());
            pstmt.setString(8, LocalDateTime.now().toString());

            int filasActualizadas = pstmt.executeUpdate();

            if (filasActualizadas > 0) {
                LOGGER.info("📊 Jugador actualizado: " + jugador.getNombreJugador() +
                        " | Partidas: " + jugador.getPartidasJugadas() +
                        " | Saldo: $" + jugador.getDineroActual());
            } else {
                LOGGER.warning("⚠️ No se actualizó ningún jugador - puede que no exista jugador actual");
            }

            // También actualizar tabla de saldo para compatibilidad
            actualizarSaldoInterno(jugador.getDineroActual());

        } catch (SQLException e) {
            throw new BaseDatosException("Error al actualizar jugador", e);
        }
    }

    private void actualizarSaldoInterno(double saldo) throws SQLException {
        String actualizar = """
            INSERT OR REPLACE INTO saldo (id, cantidad, fecha_actualizacion) 
            VALUES (1, ?, ?)
        """;

        try (PreparedStatement pstmt = conexion.prepareStatement(actualizar)) {
            pstmt.setDouble(1, saldo);
            pstmt.setString(2, LocalDateTime.now().toString());
            pstmt.executeUpdate();
        }
    }

    @Override
    public boolean existeJugadorActual() throws BaseDatosException {
        String consulta = "SELECT COUNT(*) FROM jugadores WHERE es_jugador_actual = 1";
        try (PreparedStatement pstmt = conexion.prepareStatement(consulta);
             ResultSet rs = pstmt.executeQuery()) {
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            throw new BaseDatosException("Error al verificar jugador actual", e);
        }
    }

    @Override
    public void eliminarJugadorActual() throws BaseDatosException {
        String actualizar = "UPDATE jugadores SET es_jugador_actual = 0 WHERE es_jugador_actual = 1";
        try (PreparedStatement pstmt = conexion.prepareStatement(actualizar)) {
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new BaseDatosException("Error al limpiar jugador actual", e);
        }
    }

    @Override
    public void guardarResultadoPartida(String tipoResultado) throws BaseDatosException {
        if (!existeJugadorActual()) {
            LOGGER.warning("⚠️ No hay jugador actual para guardar resultado: " + tipoResultado);
            return;
        }

        // *** CORRECCIÓN BUG 2: Mejorar la lógica de guardado de estadísticas ***
        try {
            EstadisticasJugador jugador = obtenerJugadorActual();

            LOGGER.info("💾 Guardando resultado: " + tipoResultado + " para " + jugador.getNombreJugador());

            switch (tipoResultado.toLowerCase()) {
                case "ganada":
                case "victoria":
                case "blackjack":
                    jugador.incrementarPartidasGanadas();
                    LOGGER.info("✅ Partida ganada registrada");
                    break;
                case "perdida":
                case "derrota":
                    jugador.incrementarPartidasPerdidas();
                    LOGGER.info("❌ Partida perdida registrada");
                    break;
                case "empate":
                    jugador.incrementarPartidasEmpatadas();
                    LOGGER.info("🤝 Empate registrado");
                    break;
                case "rendida":
                case "rendicion":
                    jugador.incrementarPartidasRendidas();
                    LOGGER.info("🏳️ Rendición registrada");
                    break;
                default:
                    LOGGER.warning("⚠️ Tipo de resultado no reconocido: " + tipoResultado);
                    // Aún así, incrementar partidas jugadas
                    jugador.incrementarPartidasJugadas();
                    break;
            }

            actualizarJugador(jugador);
            LOGGER.info("📊 Estadísticas actualizadas: " + jugador.toString());

        } catch (BaseDatosException e) {
            LOGGER.log(Level.SEVERE, "Error al guardar resultado de partida", e);
            throw e;
        }
    }

    @Override
    public List<EstadisticasJugador> obtenerTodasLasEstadisticas() throws BaseDatosException {
        List<EstadisticasJugador> estadisticas = new ArrayList<>();

        // *** CORRECCIÓN BUG 2: Cambiar consulta para mostrar todos los jugadores, incluso sin partidas ***
        String consulta = """
            SELECT nombre, partidas_jugadas, partidas_ganadas, partidas_perdidas, 
                   partidas_empatadas, partidas_rendidas, maximo_dinero_obtenido, dinero_actual
            FROM jugadores 
            ORDER BY maximo_dinero_obtenido DESC, partidas_ganadas DESC, fecha_creacion DESC
        """;

        try (PreparedStatement pstmt = conexion.prepareStatement(consulta);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                EstadisticasJugador estadistica = new EstadisticasJugador(
                        rs.getString("nombre"),
                        rs.getInt("partidas_jugadas"),
                        rs.getInt("partidas_ganadas"),
                        rs.getInt("partidas_perdidas"),
                        rs.getInt("partidas_empatadas"),
                        rs.getInt("partidas_rendidas"),
                        rs.getDouble("maximo_dinero_obtenido"),
                        rs.getDouble("dinero_actual")
                );
                estadisticas.add(estadistica);
                LOGGER.info("📊 Estadística cargada: " + estadistica.getNombreJugador() +
                        " - Partidas: " + estadistica.getPartidasJugadas());
            }

            LOGGER.info("📊 Total estadísticas cargadas: " + estadisticas.size());

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al obtener estadísticas", e);
            throw new BaseDatosException("Error al obtener estadísticas", e);
        }

        return estadisticas;
    }

    // *** CORRECCIÓN BUG 2: Método para debug - verificar estado de la base de datos ***
    public void verificarEstadoBaseDatos() throws BaseDatosException {
        try {
            // Verificar cuántos jugadores hay
            String consulta1 = "SELECT COUNT(*) as total FROM jugadores";
            try (PreparedStatement pstmt = conexion.prepareStatement(consulta1);
                 ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    LOGGER.info("🔍 Total jugadores en BD: " + rs.getInt("total"));
                }
            }

            // Verificar jugador actual
            String consulta2 = "SELECT nombre, partidas_jugadas FROM jugadores WHERE es_jugador_actual = 1";
            try (PreparedStatement pstmt = conexion.prepareStatement(consulta2);
                 ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    LOGGER.info("🔍 Jugador actual: " + rs.getString("nombre") +
                            " - Partidas: " + rs.getInt("partidas_jugadas"));
                } else {
                    LOGGER.info("🔍 No hay jugador actual");
                }
            }

        } catch (SQLException e) {
            throw new BaseDatosException("Error al verificar estado de BD", e);
        }
    }

    // Métodos para mantener compatibilidad
    @Override
    public double obtenerSaldo() throws BaseDatosException {
        if (existeJugadorActual()) {
            return obtenerJugadorActual().getDineroActual();
        } else {
            // Fallback al método anterior
            String consulta = "SELECT cantidad FROM saldo WHERE id = 1";
            try (PreparedStatement pstmt = conexion.prepareStatement(consulta);
                 ResultSet rs = pstmt.executeQuery()) {

                if (rs.next()) {
                    return rs.getDouble("cantidad");
                } else {
                    return SALDO_INICIAL;
                }
            } catch (SQLException e) {
                throw new BaseDatosException("Error al obtener el saldo", e);
            }
        }
    }

    @Override
    public void actualizarSaldo(double nuevoSaldo) throws BaseDatosException, SQLException {
        if (existeJugadorActual()) {
            EstadisticasJugador jugador = obtenerJugadorActual();
            jugador.setDineroActual(nuevoSaldo);
            actualizarJugador(jugador);
        } else {
            // Fallback al método anterior
            actualizarSaldoInterno(nuevoSaldo);
        }
    }

    @Override
    public void guardarEstadistica(String tipoJuego, boolean gano, double apuesta, double ganancia) throws BaseDatosException {
        // Método mantenido para compatibilidad - ahora también actualiza estadísticas del jugador
        String insertar = """
            INSERT INTO estadisticas (jugador_id, fecha, tipo_juego, gano, apuesta, ganancia, tipo_resultado) 
            VALUES ((SELECT id FROM jugadores WHERE es_jugador_actual = 1), ?, ?, ?, ?, ?, ?)
        """;

        try (PreparedStatement pstmt = conexion.prepareStatement(insertar)) {
            pstmt.setString(1, LocalDateTime.now().toString());
            pstmt.setString(2, tipoJuego);
            pstmt.setBoolean(3, gano);
            pstmt.setDouble(4, apuesta);
            pstmt.setDouble(5, ganancia);
            pstmt.setString(6, gano ? "ganada" : "perdida");
            pstmt.executeUpdate();

            LOGGER.info("📈 Estadística detallada guardada: " + tipoJuego + " - " + (gano ? "Victoria" : "Derrota"));
        } catch (SQLException e) {
            throw new BaseDatosException("Error al guardar estadística", e);
        }
    }

    @Override
    public void cerrarConexion() throws BaseDatosException {
        if (conexion != null) {
            try {
                conexion.close();
                LOGGER.info("Conexión a base de datos cerrada");
            } catch (SQLException e) {
                throw new BaseDatosException("Error al cerrar la conexión", e);
            }
        }
    }
}