// IBaseDatosService.java - Interfaz actualizada con método de debug
package com.blackjack.bj.service;

import com.blackjack.bj.exception.BaseDatosException;
import com.blackjack.bj.model.EstadisticasJugador;

import java.sql.SQLException;
import java.util.List;

public interface IBaseDatosService {
    void inicializar() throws BaseDatosException;

    // Métodos de saldo (mantener compatibilidad)
    double obtenerSaldo() throws BaseDatosException;
    void actualizarSaldo(double nuevoSaldo) throws BaseDatosException, SQLException;

    // Métodos de jugadores
    EstadisticasJugador crearJugador(String nombre) throws BaseDatosException;
    EstadisticasJugador obtenerJugadorActual() throws BaseDatosException;
    void actualizarJugador(EstadisticasJugador jugador) throws BaseDatosException;
    boolean existeJugadorActual() throws BaseDatosException;
    void eliminarJugadorActual() throws BaseDatosException;

    // Métodos de estadísticas
    void guardarEstadistica(String tipoJuego, boolean gano, double apuesta, double ganancia) throws BaseDatosException;
    void guardarResultadoPartida(String tipoResultado) throws BaseDatosException;
    List<EstadisticasJugador> obtenerTodasLasEstadisticas() throws BaseDatosException;

    // *** NUEVO: Método para debug ***
    void verificarEstadoBaseDatos() throws BaseDatosException;

    void cerrarConexion() throws BaseDatosException;
}