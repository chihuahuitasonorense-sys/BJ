// EstadisticasJugador.java
package com.blackjack.bj.model;

public class EstadisticasJugador {
    private String nombreJugador;
    private int partidasJugadas;
    private int partidasGanadas;
    private int partidasPerdidas;
    private int partidasEmpatadas;
    private int partidasRendidas;
    private double maximoDineroObtenido;
    private double dineroActual;

    public EstadisticasJugador(String nombreJugador) {
        this.nombreJugador = nombreJugador;
        this.partidasJugadas = 0;
        this.partidasGanadas = 0;
        this.partidasPerdidas = 0;
        this.partidasEmpatadas = 0;
        this.partidasRendidas = 0;
        this.maximoDineroObtenido = 1000.0;
        this.dineroActual = 1000.0;
    }

    // Constructor completo para cargar desde BD
    public EstadisticasJugador(String nombreJugador, int partidasJugadas, int partidasGanadas,
                               int partidasPerdidas, int partidasEmpatadas, int partidasRendidas,
                               double maximoDineroObtenido, double dineroActual) {
        this.nombreJugador = nombreJugador;
        this.partidasJugadas = partidasJugadas;
        this.partidasGanadas = partidasGanadas;
        this.partidasPerdidas = partidasPerdidas;
        this.partidasEmpatadas = partidasEmpatadas;
        this.partidasRendidas = partidasRendidas;
        this.maximoDineroObtenido = maximoDineroObtenido;
        this.dineroActual = dineroActual;
    }

    // Getters y Setters
    public String getNombreJugador() {
        return nombreJugador;
    }

    public void setNombreJugador(String nombreJugador) {
        this.nombreJugador = nombreJugador;
    }

    public int getPartidasJugadas() {
        return partidasJugadas;
    }

    public void setPartidasJugadas(int partidasJugadas) {
        this.partidasJugadas = partidasJugadas;
    }

    public int getPartidasGanadas() {
        return partidasGanadas;
    }

    public void setPartidasGanadas(int partidasGanadas) {
        this.partidasGanadas = partidasGanadas;
    }

    public int getPartidasPerdidas() {
        return partidasPerdidas;
    }

    public void setPartidasPerdidas(int partidasPerdidas) {
        this.partidasPerdidas = partidasPerdidas;
    }

    public int getPartidasEmpatadas() {
        return partidasEmpatadas;
    }

    public void setPartidasEmpatadas(int partidasEmpatadas) {
        this.partidasEmpatadas = partidasEmpatadas;
    }

    public int getPartidasRendidas() {
        return partidasRendidas;
    }

    public void setPartidasRendidas(int partidasRendidas) {
        this.partidasRendidas = partidasRendidas;
    }

    public double getMaximoDineroObtenido() {
        return maximoDineroObtenido;
    }

    public void setMaximoDineroObtenido(double maximoDineroObtenido) {
        this.maximoDineroObtenido = maximoDineroObtenido;
    }

    public double getDineroActual() {
        return dineroActual;
    }

    public void setDineroActual(double dineroActual) {
        this.dineroActual = dineroActual;
        // Actualizar máximo si es necesario
        if (dineroActual > maximoDineroObtenido) {
            this.maximoDineroObtenido = dineroActual;
        }
    }

    // Métodos de utilidad
    public void incrementarPartidasJugadas() {
        this.partidasJugadas++;
    }

    public void incrementarPartidasGanadas() {
        this.partidasGanadas++;
        incrementarPartidasJugadas();
    }

    public void incrementarPartidasPerdidas() {
        this.partidasPerdidas++;
        incrementarPartidasJugadas();
    }

    public void incrementarPartidasEmpatadas() {
        this.partidasEmpatadas++;
        incrementarPartidasJugadas();
    }

    public void incrementarPartidasRendidas() {
        this.partidasRendidas++;
        this.partidasPerdidas++; // Las rendidas también cuentan como perdidas
        incrementarPartidasJugadas();
    }

    public double getPorcentajeVictorias() {
        if (partidasJugadas == 0) return 0.0;
        return (double) partidasGanadas / partidasJugadas * 100.0;
    }

    public double getPorcentajePerdidas() {
        if (partidasJugadas == 0) return 0.0;
        return (double) partidasPerdidas / partidasJugadas * 100.0;
    }

    public double getPorcentajeEmpates() {
        if (partidasJugadas == 0) return 0.0;
        return (double) partidasEmpatadas / partidasJugadas * 100.0;
    }

    public void reiniciarEstadisticas() {
        this.partidasJugadas = 0;
        this.partidasGanadas = 0;
        this.partidasPerdidas = 0;
        this.partidasEmpatadas = 0;
        this.partidasRendidas = 0;
        this.maximoDineroObtenido = 1000.0;
        this.dineroActual = 1000.0;
    }

    @Override
    public String toString() {
        return String.format(
                "Jugador: %s | Partidas: %d | Ganadas: %d | Perdidas: %d | Empates: %d | Rendidas: %d | Máximo: $%.2f | Actual: $%.2f",
                nombreJugador, partidasJugadas, partidasGanadas, partidasPerdidas,
                partidasEmpatadas, partidasRendidas, maximoDineroObtenido, dineroActual
        );
    }
}
