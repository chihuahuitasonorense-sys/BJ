// Dealer.java
package com.blackjack.bj.model;

public class Dealer {
    private final Mano mano;
    private boolean cartaOcultaVisible;

    public Dealer() {
        this.mano = new Mano();
        this.cartaOcultaVisible = false;
    }

    public Mano getMano() {
        return mano;
    }

    public void agregarCarta(Carta carta) {
        mano.agregarCarta(carta);
    }

    public void mostrarCartaOculta() {
        cartaOcultaVisible = true;
    }

    public boolean isCartaOcultaVisible() {
        return cartaOcultaVisible;
    }

    public boolean debeTomarCarta() {
        return mano.getValor() < 17;
    }

    public int getValorVisible() {
        if (!cartaOcultaVisible && mano.cantidadCartas() >= 2) {
            // Solo mostrar el valor de la primera carta
            Carta primeraCarta = mano.getCartas().get(0);
            return primeraCarta.getValorNumerico();
        }
        return mano.getValor();
    }

    public void reiniciar() {
        mano.limpiar();
        cartaOcultaVisible = false;
    }

    public String toString() {
        if (!cartaOcultaVisible && mano.cantidadCartas() >= 2) {
            return mano.getCartas().get(0) + ", [Carta Oculta]";
        }
        return mano.toString();
    }
}