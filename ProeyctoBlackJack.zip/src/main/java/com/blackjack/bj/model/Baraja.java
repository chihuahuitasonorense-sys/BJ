// Baraja.java
package com.blackjack.bj.model;

import com.blackjack.bj.exception.BarajaVaciaException;
import java.util.*;

public class Baraja {
    private static final String[] VALORES = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    private final List<Carta> cartas;
    private final Random random;

    public Baraja() {
        this.cartas = new ArrayList<>();
        this.random = new Random();
        inicializarBaraja();
    }

    public Baraja(long seed) {
        this.cartas = new ArrayList<>();
        this.random = new Random(seed);
        inicializarBaraja();
    }

    private void inicializarBaraja() {
        cartas.clear();
        for (Palo palo : Palo.values()) {
            for (String valor : VALORES) {
                cartas.add(new Carta(valor, palo));
            }
        }
    }

    public void mezclar() {
        Collections.shuffle(cartas, random);
    }

    public Carta repartirCarta() throws BarajaVaciaException {
        if (cartas.isEmpty()) {
            throw new BarajaVaciaException();
        }
        return cartas.remove(cartas.size() - 1);
    }

    public int cartasRestantes() {
        return cartas.size();
    }

    public boolean estaVacia() {
        return cartas.isEmpty();
    }

    public void resetear() {
        inicializarBaraja();
        mezclar();
    }
}