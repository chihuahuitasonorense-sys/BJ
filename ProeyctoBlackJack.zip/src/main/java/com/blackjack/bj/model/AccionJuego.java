// AccionJuego.java
package com.blackjack.bj.model;

public enum AccionJuego {
    PEDIR_CARTA,
    PLANTARSE,
    DOBLAR,
    DIVIDIR,
    RENDIRSE
}