// Mano.java - Versión corregida
package com.blackjack.bj.model;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class Mano {
    private static final Logger LOGGER = Logger.getLogger(Mano.class.getName());
    private final List<Carta> cartas;

    public Mano() {
        this.cartas = new ArrayList<>();
    }

    public void agregarCarta(Carta carta) {
        if (carta == null) {
            throw new IllegalArgumentException("La carta no puede ser null");
        }
        cartas.add(carta);
        LOGGER.fine("Carta agregada: " + carta + " | Total cartas: " + cartas.size());
    }

    public List<Carta> getCartas() {
        return new ArrayList<>(cartas);
    }

    public int getValor() {
        int valor = 0;
        int ases = 0;

        for (Carta carta : cartas) {
            if (carta.esAs()) {
                ases++;
                valor += 11;
            } else {
                valor += carta.getValorNumerico();
            }
        }

        // Ajustar valor de los ases si es necesario
        while (valor > 21 && ases > 0) {
            valor -= 10; // Cambiar As de 11 a 1
            ases--;
        }

        return valor;
    }

    public boolean esBlackjack() {
        return cartas.size() == 2 && getValor() == 21;
    }

    public boolean estaPasado() {
        return getValor() > 21;
    }

    public int cantidadCartas() {
        return cartas.size();
    }

    // *** CORRECCIÓN BUG 1: Método limpiar mejorado con logging ***
    public void limpiar() {
        int cartasAnteriores = cartas.size();
        cartas.clear();

        if (cartasAnteriores > 0) {
            LOGGER.info("🧹 Mano limpiada: " + cartasAnteriores + " cartas removidas");
        }

        // *** Verificación adicional para asegurar que esté realmente vacía ***
        if (!cartas.isEmpty()) {
            LOGGER.severe("🚨 ERROR CRÍTICO: La mano no se limpió correctamente! Cartas restantes: " + cartas.size());
            // Forzar limpieza adicional
            cartas.removeAll(new ArrayList<>(cartas));
        }

        LOGGER.fine("✅ Verificación: Mano tiene " + cartas.size() + " cartas después de limpiar");
    }

    public boolean puedePartir() {
        if (cartas.size() != 2) {
            return false;
        }

        Carta carta1 = cartas.get(0);
        Carta carta2 = cartas.get(1);

        // Se puede partir si ambas cartas tienen el mismo valor
        return carta1.getValorNumerico() == carta2.getValorNumerico();
    }

    // *** NUEVO: Método para debug/verificación ***
    public boolean estaVacia() {
        return cartas.isEmpty();
    }

    // *** NUEVO: Método para obtener información de debug ***
    public String getEstadoDebug() {
        return String.format("Mano: %d cartas, Valor: %d, Vacía: %s",
                cartas.size(), getValor(), estaVacia());
    }

    @Override
    public String toString() {
        if (cartas.isEmpty()) {
            return "Sin cartas";
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cartas.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(cartas.get(i));
        }
        sb.append(" (Valor: ").append(getValor()).append(")");
        return sb.toString();
    }
}