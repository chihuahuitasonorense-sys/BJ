// Jugador.java - Versión corregida
package com.blackjack.bj.model;

import com.blackjack.bj.exception.SaldoInsuficienteException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class Jugador {
    private static final Logger LOGGER = Logger.getLogger(Jugador.class.getName());

    private final String nombre;
    private double saldo;
    private final List<Mano> manos;
    private final List<Double> apuestas;
    private int manoActiva;

    public Jugador(String nombre, double saldoInicial) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío");
        }
        if (saldoInicial < 0) {
            throw new IllegalArgumentException("El saldo inicial no puede ser negativo");
        }

        this.nombre = nombre;
        this.saldo = saldoInicial;
        this.manos = new ArrayList<>();
        this.apuestas = new ArrayList<>();
        this.manoActiva = 0;

        // Inicializar con una mano
        manos.add(new Mano());
        apuestas.add(0.0);

        LOGGER.fine("Jugador creado: " + nombre + " con saldo: $" + saldoInicial);
    }

    public String getNombre() {
        return nombre;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        if (saldo < 0) {
            throw new IllegalArgumentException("El saldo no puede ser negativo");
        }
        this.saldo = saldo;
    }

    public void apostar(double cantidad) throws SaldoInsuficienteException {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La apuesta debe ser mayor a 0");
        }
        if (cantidad > saldo) {
            throw new SaldoInsuficienteException(saldo, cantidad);
        }

        saldo -= cantidad;
        apuestas.set(manoActiva, cantidad);

        LOGGER.fine("Apuesta realizada: $" + cantidad + " | Saldo restante: $" + saldo);
    }

    public void ganar(double cantidad) {
        saldo += cantidad;
        LOGGER.fine("Ganancia: $" + cantidad + " | Nuevo saldo: $" + saldo);
    }

    public List<Mano> getManos() {
        return new ArrayList<>(manos);
    }

    public Mano getManoActiva() {
        if (manoActiva >= manos.size()) {
            LOGGER.warning("⚠️ Índice de mano activa inválido: " + manoActiva + " | Total manos: " + manos.size());
            manoActiva = 0;
        }
        return manos.get(manoActiva);
    }

    public int getManoActivaIndex() {
        return manoActiva;
    }

    public void siguienteMano() {
        if (manoActiva < manos.size() - 1) {
            manoActiva++;
            LOGGER.fine("Cambiando a siguiente mano: " + manoActiva);
        }
    }

    public boolean tieneMasManos() {
        return manoActiva < manos.size() - 1;
    }

    public double getApuestaActiva() {
        if (manoActiva >= apuestas.size()) {
            LOGGER.warning("⚠️ Índice de apuesta activa inválido: " + manoActiva);
            return 0.0;
        }
        return apuestas.get(manoActiva);
    }

    public List<Double> getApuestas() {
        return new ArrayList<>(apuestas);
    }

    public void partirMano() {
        if (!getManoActiva().puedePartir()) {
            throw new IllegalStateException("No se puede partir esta mano");
        }

        Mano manoOriginal = getManoActiva();
        List<Carta> cartasOriginales = manoOriginal.getCartas();

        // Crear nueva mano con la segunda carta
        Mano nuevaMano = new Mano();
        nuevaMano.agregarCarta(cartasOriginales.get(1));

        // Limpiar la mano original y agregar solo la primera carta
        manoOriginal.limpiar();
        manoOriginal.agregarCarta(cartasOriginales.get(0));

        // Agregar la nueva mano después de la actual
        manos.add(manoActiva + 1, nuevaMano);
        apuestas.add(manoActiva + 1, getApuestaActiva());

        // Descontar la apuesta adicional del saldo
        saldo -= getApuestaActiva();

        LOGGER.info("✂️ Mano partida - Total manos: " + manos.size());
    }

    // *** CORRECCIÓN BUG 1: Método reiniciarManos mejorado ***
    public void reiniciarManos() {
        LOGGER.info("🔄 Reiniciando manos del jugador...");

        // Log del estado anterior
        LOGGER.fine("Estado anterior - Manos: " + manos.size() + ", Mano activa: " + manoActiva);
        for (int i = 0; i < manos.size(); i++) {
            LOGGER.fine("Mano " + i + ": " + manos.get(i).getEstadoDebug());
        }

        // Limpiar todas las manos existentes
        for (Mano mano : manos) {
            mano.limpiar();
        }

        // Crear nueva lista limpia
        manos.clear();
        apuestas.clear();

        // Agregar una sola mano nueva
        manos.add(new Mano());
        apuestas.add(0.0);
        manoActiva = 0;

        // *** Verificación adicional ***
        if (!manos.get(0).estaVacia()) {
            LOGGER.severe("🚨 ERROR CRÍTICO: La mano reiniciada no está vacía!");
            manos.get(0).limpiar();
        }

        LOGGER.info("✅ Manos reiniciadas - Total: " + manos.size() + ", Cartas en mano activa: " + getManoActiva().cantidadCartas());
    }

    // *** NUEVO: Método para debug/verificación ***
    public String getEstadoDebug() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Jugador: %s | Saldo: $%.2f | Manos: %d | Mano activa: %d\n",
                nombre, saldo, manos.size(), manoActiva));

        for (int i = 0; i < manos.size(); i++) {
            sb.append(String.format("  Mano %d: %s | Apuesta: $%.2f\n",
                    i, manos.get(i).getEstadoDebug(),
                    i < apuestas.size() ? apuestas.get(i) : 0.0));
        }

        return sb.toString();
    }

    @Override
    public String toString() {
        return String.format("%s (Saldo: $%.2f)", nombre, saldo);
    }
}