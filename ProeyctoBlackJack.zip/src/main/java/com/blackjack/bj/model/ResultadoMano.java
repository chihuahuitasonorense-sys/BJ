// ResultadoMano.java
package com.blackjack.bj.model;

public enum ResultadoMano {
    JUGADOR_GANA,
    DEALER_GANA,
    EMPATE,
    BLACKJACK_JUGADOR,
    BLACKJACK_DEALER,
    JUGADOR_SE_PASA,
    DEALER_SE_PASA
}