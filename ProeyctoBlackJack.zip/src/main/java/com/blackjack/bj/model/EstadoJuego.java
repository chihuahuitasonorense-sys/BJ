// EstadoJuego.java
package com.blackjack.bj.model;

public enum EstadoJuego {
    ESPERANDO_APUESTA,
    REPARTIENDO,
    TURNO_JUGADOR,
    TURNO_DEALER,
    JUEGO_TERMINADO
}