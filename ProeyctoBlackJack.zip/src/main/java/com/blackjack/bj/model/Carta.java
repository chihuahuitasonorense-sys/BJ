// Carta.java
        package com.blackjack.bj.model;

import java.util.Objects;

public class Carta {
    private final String valor;
    private final Palo palo;

    public Carta(String valor, Palo palo) {
        if (valor == null || palo == null) {
            throw new IllegalArgumentException("El valor y palo no pueden ser null");
        }
        this.valor = valor;
        this.palo = palo;
    }

    public String getValor() {
        return valor;
    }

    public Palo getPalo() {
        return palo;
    }

    /**
     * Obtiene el valor numérico de la carta para el Blackjack
     * @return valor numérico (As = 11, figuras = 10, números = valor)
     */
    public int getValorNumerico() {
        switch (valor) {
            case "A":
                return 11;
            case "J":
            case "Q":
            case "K":
                return 10;
            default:
                try {
                    return Integer.parseInt(valor);
                } catch (NumberFormatException e) {
                    throw new IllegalStateException("Valor de carta inválido: " + valor);
                }
        }
    }

    public boolean esAs() {
        return "A".equals(valor);
    }

    @Override
    public String toString() {
        return valor + " " + palo.getSimbolo();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Carta carta = (Carta) obj;
        return Objects.equals(valor, carta.valor) && palo == carta.palo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(valor, palo);
    }
}
