// Main.java
package com.blackjack.bj;

import com.blackjack.bj.controller.MenuController;
import com.blackjack.bj.exception.BaseDatosException;
import com.blackjack.bj.service.BaseDatosService;
import com.blackjack.bj.service.IBaseDatosService;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main extends Application {
    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());
    private IBaseDatosService baseDatosService;

    public static void main(String[] args) {
        // Configurar el sistema de logging
        System.setProperty("java.util.logging.SimpleFormatter.format",
                "%1$tF %1$tT %4$s %2$s %5$s%6$s%n");

        LOGGER.info("Iniciando aplicación Blackjack...");
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            // Inicializar servicios
            inicializarServicios();

            // Configurar ventana principal
            configurarVentanaPrincipal(primaryStage);

            // Cargar y mostrar el menú principal
            mostrarMenuPrincipal(primaryStage);

            LOGGER.info("Aplicación iniciada correctamente");

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error al iniciar la aplicación", e);
            mostrarErrorCritico("Error al iniciar la aplicación: " + e.getMessage());
            Platform.exit();
        }
    }

    private void inicializarServicios() throws BaseDatosException {
        LOGGER.info("Inicializando servicios...");
        baseDatosService = new BaseDatosService();
        LOGGER.info("Servicios inicializados correctamente");
    }

    private void configurarVentanaPrincipal(Stage primaryStage) {
        primaryStage.setTitle("Blackjack - Juego de Cartas");
        primaryStage.setResizable(false);

        // Configurar evento de cierre
        primaryStage.setOnCloseRequest(event -> {
            try {
                if (baseDatosService != null) {
                    baseDatosService.cerrarConexion();
                    LOGGER.info("Conexiones cerradas correctamente");
                }
            } catch (BaseDatosException e) {
                LOGGER.log(Level.WARNING, "Error al cerrar conexiones", e);
            }
            Platform.exit();
        });

        // Agregar icono si está disponible (opcional)
        try {
            primaryStage.getIcons().add(new Image(
                    getClass().getResourceAsStream("/com/blackjack/bj/icon.png")
            ));
        } catch (Exception e) {
            LOGGER.info("Icono de aplicación no encontrado, usando icono por defecto");
        }
    }

    private void mostrarMenuPrincipal(Stage primaryStage) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/blackjack/bj/menu.fxml"));
        Parent root = loader.load();

        // Obtener el controlador y configurarlo
        MenuController menuController = loader.getController();
        menuController.setBaseDatosService(baseDatosService);
        menuController.setPrimaryStage(primaryStage);

        Scene scene = new Scene(root, 500, 400);

        // Aplicar estilo de fondo a la escena
        scene.getRoot().setStyle("-fx-background-color: #ecf0f1; -fx-font-family: 'Arial', 'Helvetica', 'sans-serif';");

        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
        primaryStage.show();
    }

    private void mostrarErrorCritico(String mensaje) {
        try {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Crítico");
            alert.setHeaderText("No se pudo iniciar la aplicación");
            alert.setContentText(mensaje);
            alert.showAndWait();
        } catch (Exception e) {
            // Si no se puede mostrar el diálogo, mostrar en consola
            System.err.println("Error crítico: " + mensaje);
            e.printStackTrace();
        }
    }

    @Override
    public void stop() {
        LOGGER.info("Cerrando aplicación...");
        try {
            if (baseDatosService != null) {
                baseDatosService.cerrarConexion();
            }
        } catch (BaseDatosException e) {
            LOGGER.log(Level.WARNING, "Error al cerrar servicios", e);
        }
        LOGGER.info("Aplicación cerrada");
    }
}