// MenuController.java - Versión mejorada
package com.blackjack.bj.controller;

import com.blackjack.bj.exception.BaseDatosException;
import com.blackjack.bj.model.EstadisticasJugador;
import com.blackjack.bj.service.IBaseDatosService;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MenuController implements Initializable {
    private static final Logger LOGGER = Logger.getLogger(MenuController.class.getName());

    @FXML private Label lblTitulo;
    @FXML private Button btnJugar;
    @FXML private Button btnReglas;
    @FXML private Button btnEstadisticas;
    @FXML private Button btnSalir;
    @FXML private Label lblSaldo;
    @FXML private Label lblJugador;

    private IBaseDatosService baseDatosService;
    private Stage primaryStage;
    private EstadisticasJugador jugadorActual;

    public void setBaseDatosService(IBaseDatosService baseDatosService) {
        this.baseDatosService = baseDatosService;
        inicializarJugador();
        actualizarInterfaz();
    }

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        configurarInterfaz();
    }

    private void configurarInterfaz() {
        lblTitulo.setText("♠ BLACKJACK ♥");
        lblTitulo.setStyle("-fx-font-size: 32px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 3, 0, 2, 2);");

        // Configurar botones con estilos detallados
        configurarBotonJugar();
        configurarBotonReglas();
        configurarBotonEstadisticas();
        configurarBotonSalir();
    }

    private void configurarBotonJugar() {
        String estiloBase = "-fx-background-color: linear-gradient(to bottom, #27ae60, #229954); " +
                "-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; " +
                "-fx-background-radius: 5px; -fx-cursor: hand; -fx-padding: 10px 20px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 2, 0, 1, 1);";

        btnJugar.setStyle(estiloBase);
        configurarEfectoHover(btnJugar, estiloBase, "#229954", "#1e8449");
    }

    private void configurarBotonReglas() {
        String estiloBase = "-fx-background-color: linear-gradient(to bottom, #3498db, #2980b9); " +
                "-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; " +
                "-fx-background-radius: 5px; -fx-cursor: hand; -fx-padding: 8px 16px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 2, 0, 1, 1);";

        btnReglas.setStyle(estiloBase);
        configurarEfectoHover(btnReglas, estiloBase, "#2980b9", "#21618c");
    }

    private void configurarBotonEstadisticas() {
        String estiloBase = "-fx-background-color: linear-gradient(to bottom, #9b59b6, #8e44ad); " +
                "-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; " +
                "-fx-background-radius: 5px; -fx-cursor: hand; -fx-padding: 8px 16px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 2, 0, 1, 1);";

        btnEstadisticas.setStyle(estiloBase);
        configurarEfectoHover(btnEstadisticas, estiloBase, "#8e44ad", "#7d3c98");
    }

    private void configurarBotonSalir() {
        String estiloBase = "-fx-background-color: linear-gradient(to bottom, #e74c3c, #c0392b); " +
                "-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; " +
                "-fx-background-radius: 5px; -fx-cursor: hand; -fx-padding: 8px 16px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 2, 0, 1, 1);";

        btnSalir.setStyle(estiloBase);
        configurarEfectoHover(btnSalir, estiloBase, "#c0392b", "#a93226");
    }

    private void configurarEfectoHover(Button boton, String estiloBase, String color1, String color2) {
        boton.setOnMouseEntered(e -> {
            String estiloHover = estiloBase.replace("linear-gradient(to bottom, #" + color1.substring(1),
                    "linear-gradient(to bottom, #" + color1.substring(1) + ", #" + color2.substring(1)) +
                    " -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 3, 0, 1, 1); " +
                    "-fx-scale-x: 1.02; -fx-scale-y: 1.02;";
            boton.setStyle(estiloHover);
        });

        boton.setOnMouseExited(e -> boton.setStyle(estiloBase));
    }

    private void inicializarJugador() {
        try {
            if (!baseDatosService.existeJugadorActual()) {
                // Pedir nombre del jugador
                String nombre = pedirNombreJugador();
                if (nombre != null && !nombre.trim().isEmpty()) {
                    jugadorActual = baseDatosService.crearJugador(nombre);
                    LOGGER.info("Nuevo jugador creado: " + nombre);
                } else {
                    // Si no se ingresa nombre, crear jugador por defecto
                    jugadorActual = baseDatosService.crearJugador("Jugador");
                }
            } else {
                jugadorActual = baseDatosService.obtenerJugadorActual();
                LOGGER.info("Jugador actual cargado: " + jugadorActual.getNombreJugador());
            }
        } catch (BaseDatosException e) {
            LOGGER.log(Level.SEVERE, "Error al inicializar jugador", e);
            mostrarAlerta("Error", "No se pudo cargar la información del jugador: " + e.getMessage(),
                    Alert.AlertType.ERROR);
            jugadorActual = new EstadisticasJugador("Jugador");
        }
    }

    private String pedirNombreJugador() {
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Bienvenido al Blackjack");
        dialog.setHeaderText("¡Nueva partida!");
        dialog.setContentText("Ingresa tu nombre:");
        dialog.initOwner(primaryStage);

        // Configurar estilo del diálogo
        dialog.getDialogPane().setStyle("-fx-background-color: #ecf0f1; -fx-font-family: Arial;");

        // Crear campo de texto
        TextField nombreField = new TextField();
        nombreField.setPromptText("Tu nombre aquí...");
        nombreField.setStyle("-fx-font-size: 14px; -fx-padding: 8px;");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));
        grid.add(new Label("Nombre:"), 0, 0);
        grid.add(nombreField, 1, 0);

        dialog.getDialogPane().setContent(grid);

        // Botones
        ButtonType btnAceptar = new ButtonType("Jugar", ButtonBar.ButtonData.OK_DONE);
        ButtonType btnCancelar = new ButtonType("Cancelar", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(btnAceptar, btnCancelar);

        // Focus en el campo de texto
        Platform.runLater(() -> nombreField.requestFocus());

        // Validación
        Button btnAceptarNode = (Button) dialog.getDialogPane().lookupButton(btnAceptar);
        btnAceptarNode.setDisable(true);

        nombreField.textProperty().addListener((observable, oldValue, newValue) -> {
            btnAceptarNode.setDisable(newValue.trim().isEmpty());
        });

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == btnAceptar) {
                String nombre = nombreField.getText().trim();
                return nombre.isEmpty() ? "Jugador" : nombre;
            }
            return null;
        });

        Optional<String> result = dialog.showAndWait();
        return result.orElse("Jugador");
    }

    public void mostrarGameOver() {
        Alert gameOverAlert = new Alert(Alert.AlertType.INFORMATION);
        gameOverAlert.setTitle("GAME OVER");
        gameOverAlert.setHeaderText("¡Te has quedado sin dinero!");
        gameOverAlert.setContentText(String.format(
                "¡Fin del juego para %s!\n\n" +
                        "Estadísticas finales:\n" +
                        "• Partidas jugadas: %d\n" +
                        "• Partidas ganadas: %d\n" +
                        "• Máximo dinero obtenido: $%.2f\n\n" +
                        "¡Empezarás una nueva partida con $1000!",
                jugadorActual.getNombreJugador(),
                jugadorActual.getPartidasJugadas(),
                jugadorActual.getPartidasGanadas(),
                jugadorActual.getMaximoDineroObtenido()
        ));

        gameOverAlert.initOwner(primaryStage);
        gameOverAlert.getDialogPane().setStyle("-fx-background-color: #ecf0f1; -fx-font-family: Arial;");

        ButtonType btnNuevaPartida = new ButtonType("Nueva Partida", ButtonBar.ButtonData.OK_DONE);
        gameOverAlert.getButtonTypes().setAll(btnNuevaPartida);

        gameOverAlert.showAndWait();

        // Iniciar nueva partida
        iniciarNuevaPartida();
    }

    private void iniciarNuevaPartida() {
        try {
            // Pedir nuevo nombre
            String nuevoNombre = pedirNombreJugador();
            if (nuevoNombre != null && !nuevoNombre.trim().isEmpty()) {
                jugadorActual = baseDatosService.crearJugador(nuevoNombre);
                actualizarInterfaz();
                LOGGER.info("Nueva partida iniciada para: " + nuevoNombre);
            }
        } catch (BaseDatosException e) {
            LOGGER.log(Level.SEVERE, "Error al iniciar nueva partida", e);
            mostrarAlerta("Error", "Error al iniciar nueva partida: " + e.getMessage(),
                    Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void onJugar() {
        try {
            // Verificar que hay saldo suficiente para jugar
            double saldoActual = jugadorActual.getDineroActual();
            if (saldoActual < 10) {
                mostrarGameOver();
                return;
            }

            abrirVentanaJuego();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error al verificar saldo", e);
            mostrarAlerta("Error", "No se pudo verificar el saldo: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void abrirVentanaJuego() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/blackjack/bj/juego.fxml"));
            Parent root = loader.load();

            JuegoController juegoController = loader.getController();
            juegoController.setBaseDatosService(baseDatosService);
            juegoController.setMenuController(this);
            juegoController.setJugadorActual(jugadorActual);

            Stage juegoStage = new Stage();
            juegoStage.setTitle("Blackjack - " + jugadorActual.getNombreJugador());
            juegoStage.setScene(new Scene(root, 900, 700));
            juegoStage.setResizable(false);
            juegoStage.initModality(Modality.WINDOW_MODAL);
            juegoStage.initOwner(primaryStage);

            // Al cerrar la ventana del juego, actualizar la interfaz
            juegoStage.setOnHidden(e -> {
                try {
                    // Recargar datos del jugador
                    if (baseDatosService.existeJugadorActual()) {
                        jugadorActual = baseDatosService.obtenerJugadorActual();
                    }
                    actualizarInterfaz();
                } catch (BaseDatosException ex) {
                    LOGGER.log(Level.WARNING, "Error al actualizar datos del jugador", ex);
                }
            });

            juegoStage.show();

        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error al abrir ventana de juego", e);
            mostrarAlerta("Error", "No se pudo abrir el juego: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void onReglas() {
        String reglas = """
            REGLAS DEL BLACKJACK
            
            OBJETIVO:
            Obtener un valor de cartas lo más cercano a 21 sin pasarse.
            
            VALORES DE CARTAS:
            • Números (2-10): Valor nominal
            • Figuras (J, Q, K): 10 puntos cada una
            • As: 11 puntos (o 1 si conviene más)
            
            ACCIONES DISPONIBLES:
            • PEDIR: Tomar otra carta
            • PLANTARSE: No tomar más cartas
            • DOBLAR: Duplicar la apuesta y tomar solo 1 carta más
            • DIVIDIR: Si tienes 2 cartas iguales, crear 2 manos separadas
            • RENDIRSE: Perder solo la mitad de la apuesta (solo con 2 cartas)
            
            BLACKJACK NATURAL:
            Si obtienes 21 con las primeras 2 cartas (As + carta de 10),
            ganas 1.5 veces tu apuesta.
            
            DEALER:
            • Debe pedir carta si tiene menos de 17
            • Debe plantarse con 17 o más
            
            GAME OVER:
            Cuando te quedes sin dinero ($0), el juego termina y 
            puedes empezar una nueva partida con $1000.
            
            ¡BUENA SUERTE!
            """;

        mostrarAlerta("Reglas del Juego", reglas, Alert.AlertType.INFORMATION);
    }

    @FXML
    private void onEstadisticas() {
        try {
            mostrarVentanaEstadisticas();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error al mostrar estadísticas", e);
            mostrarAlerta("Error", "No se pudieron cargar las estadísticas: " + e.getMessage(),
                    Alert.AlertType.ERROR);
        }
    }

    private void mostrarVentanaEstadisticas() {
        try {
            List<EstadisticasJugador> estadisticas = baseDatosService.obtenerTodasLasEstadisticas();

            Stage estadisticasStage = new Stage();
            estadisticasStage.setTitle("Estadísticas de Jugadores");
            estadisticasStage.initOwner(primaryStage);
            estadisticasStage.initModality(Modality.WINDOW_MODAL);

            VBox root = new VBox(15);
            root.setPadding(new Insets(20));
            root.setStyle("-fx-background-color: #ecf0f1;");

            // Título
            Label titulo = new Label("📊 ESTADÍSTICAS DE JUGADORES");
            titulo.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

            // Tabla de estadísticas
            TableView<EstadisticasJugador> tabla = crearTablaEstadisticas(estadisticas);

            // Botón cerrar
            Button btnCerrar = new Button("Cerrar");
            btnCerrar.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; " +
                    "-fx-font-weight: bold; -fx-padding: 10px 20px; -fx-background-radius: 5px;");
            btnCerrar.setOnAction(e -> estadisticasStage.close());

            root.getChildren().addAll(titulo, tabla, btnCerrar);

            Scene scene = new Scene(root, 800, 500);
            estadisticasStage.setScene(scene);
            estadisticasStage.showAndWait();

        } catch (BaseDatosException e) {
            LOGGER.log(Level.SEVERE, "Error al obtener estadísticas", e);
            mostrarAlerta("Error", "No se pudieron cargar las estadísticas: " + e.getMessage(),
                    Alert.AlertType.ERROR);
        }
    }

    private TableView<EstadisticasJugador> crearTablaEstadisticas(List<EstadisticasJugador> estadisticas) {
        TableView<EstadisticasJugador> tabla = new TableView<>();
        tabla.setStyle("-fx-background-color: white; -fx-border-color: #bdc3c7; -fx-border-width: 1px;");

        // Columnas
        TableColumn<EstadisticasJugador, String> colNombre = new TableColumn<>("Jugador");
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombreJugador"));
        colNombre.setPrefWidth(120);

        TableColumn<EstadisticasJugador, Integer> colJugadas = new TableColumn<>("Jugadas");
        colJugadas.setCellValueFactory(new PropertyValueFactory<>("partidasJugadas"));
        colJugadas.setPrefWidth(80);

        TableColumn<EstadisticasJugador, Integer> colGanadas = new TableColumn<>("Ganadas");
        colGanadas.setCellValueFactory(new PropertyValueFactory<>("partidasGanadas"));
        colGanadas.setPrefWidth(80);

        TableColumn<EstadisticasJugador, Integer> colPerdidas = new TableColumn<>("Perdidas");
        colPerdidas.setCellValueFactory(new PropertyValueFactory<>("partidasPerdidas"));
        colPerdidas.setPrefWidth(80);

        TableColumn<EstadisticasJugador, Integer> colEmpatadas = new TableColumn<>("Empates");
        colEmpatadas.setCellValueFactory(new PropertyValueFactory<>("partidasEmpatadas"));
        colEmpatadas.setPrefWidth(80);

        TableColumn<EstadisticasJugador, Integer> colRendidas = new TableColumn<>("Rendidas");
        colRendidas.setCellValueFactory(new PropertyValueFactory<>("partidasRendidas"));
        colRendidas.setPrefWidth(80);

        TableColumn<EstadisticasJugador, String> colMaxDinero = new TableColumn<>("Máximo $");
        colMaxDinero.setCellValueFactory(cellData -> {
            double maximo = cellData.getValue().getMaximoDineroObtenido();
            return new javafx.beans.property.SimpleStringProperty(String.format("$%.2f", maximo));
        });
        colMaxDinero.setPrefWidth(100);

        TableColumn<EstadisticasJugador, String> colPorcentaje = new TableColumn<>("% Victoria");
        colPorcentaje.setCellValueFactory(cellData -> {
            double porcentaje = cellData.getValue().getPorcentajeVictorias();
            return new javafx.beans.property.SimpleStringProperty(String.format("%.1f%%", porcentaje));
        });
        colPorcentaje.setPrefWidth(80);

        tabla.getColumns().addAll(colNombre, colJugadas, colGanadas, colPerdidas,
                colEmpatadas, colRendidas, colMaxDinero, colPorcentaje);

        tabla.getItems().addAll(estadisticas);

        // Mensaje si no hay datos
        if (estadisticas.isEmpty()) {
            Label mensaje = new Label("No hay estadísticas disponibles");
            mensaje.setStyle("-fx-text-fill: #7f8c8d; -fx-font-style: italic;");
            tabla.setPlaceholder(mensaje);
        }

        return tabla;
    }

    @FXML
    private void onSalir() {
        try {
            if (baseDatosService != null) {
                baseDatosService.cerrarConexion();
            }
        } catch (BaseDatosException e) {
            LOGGER.log(Level.WARNING, "Error al cerrar conexión de base de datos", e);
        }

        Platform.exit();
    }

    public void actualizarInterfaz() {
        if (jugadorActual != null) {
            // Mostrar nombre del jugador
            lblJugador.setText("Jugador: " + jugadorActual.getNombreJugador());
            lblJugador.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

            // Mostrar saldo con colores según la cantidad
            double saldo = jugadorActual.getDineroActual();
            lblSaldo.setText(String.format("Saldo: $%.2f", saldo));

            if (saldo < 50) {
                lblSaldo.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold; -fx-font-size: 16px; " +
                        "-fx-effect: dropshadow(three-pass-box, rgba(231,76,60,0.5), 2, 0, 0, 0);");
            } else if (saldo < 200) {
                lblSaldo.setStyle("-fx-text-fill: #f39c12; -fx-font-weight: bold; -fx-font-size: 16px;");
            } else {
                lblSaldo.setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold; -fx-font-size: 16px;");
            }
        }
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.initOwner(primaryStage);
        alert.getDialogPane().setStyle("-fx-background-color: #ecf0f1; -fx-font-family: Arial;");
        alert.showAndWait();
    }
}