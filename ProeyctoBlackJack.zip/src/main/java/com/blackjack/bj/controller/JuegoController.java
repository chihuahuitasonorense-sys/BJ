// JuegoController.java - Versión corregida para estadísticas
package com.blackjack.bj.controller;

import com.blackjack.bj.exception.BaseDatosException;
import com.blackjack.bj.exception.JuegoException;
import com.blackjack.bj.exception.SaldoInsuficienteException;
import com.blackjack.bj.model.*;
import com.blackjack.bj.service.BlackjackService;
import com.blackjack.bj.service.IBaseDatosService;
import com.blackjack.bj.service.IBlackjackService;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JuegoController implements Initializable {
    private static final Logger LOGGER = Logger.getLogger(JuegoController.class.getName());

    // Controles de la interfaz (mantener los mismos)
    @FXML private Label lblSaldoJugador;
    @FXML private Label lblApuestaActual;
    @FXML private TextField txtApuesta;
    @FXML private Button btnApostar;
    @FXML private Button btnNuevoJuego;
    @FXML private Button btnVolver;

    @FXML private Label lblCartasDealer;
    @FXML private Label lblValorDealer;
    @FXML private VBox vboxCartasDealer;

    @FXML private Label lblCartasJugador;
    @FXML private Label lblValorJugador;
    @FXML private VBox vboxCartasJugador;
    @FXML private HBox hboxManos;

    @FXML private Button btnPedir;
    @FXML private Button btnPlantarse;
    @FXML private Button btnDoblar;
    @FXML private Button btnDividir;
    @FXML private Button btnRendirse;

    @FXML private Label lblEstadoJuego;
    @FXML private Label lblMensaje;
    @FXML private TextArea txtHistorial;

    // Servicios y datos
    private IBaseDatosService baseDatosService;
    private IBlackjackService blackjackService;
    private MenuController menuController;
    private Jugador jugador;
    private EstadisticasJugador estadisticasJugador;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        configurarInterfaz();
        configurarEventos();
    }

    public void setBaseDatosService(IBaseDatosService baseDatosService) {
        this.baseDatosService = baseDatosService;
    }

    public void setMenuController(MenuController menuController) {
        this.menuController = menuController;
    }

    public void setJugadorActual(EstadisticasJugador estadisticasJugador) {
        this.estadisticasJugador = estadisticasJugador;
        inicializarJugador();
        inicializarServicioJuego();
        actualizarInterfaz();
    }

    // [MANTENER TODOS LOS MÉTODOS DE CONFIGURACIÓN DE INTERFAZ IGUAL QUE ANTES]
    // ... (todos los métodos configurarInterfaz, configurarBotonesAccion, etc. son iguales)

    private void configurarInterfaz() {
        // [MISMO CÓDIGO QUE ANTES - no necesito repetirlo aquí]
        lblEstadoJuego.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: white; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.5), 2, 0, 1, 1);");
        lblMensaje.setStyle("-fx-font-size: 14px; -fx-text-fill: #34495e;");

        configurarBotonesAccion();
        configurarCampoApuesta();
        deshabilitarBotonesAccion();

        txtHistorial.setEditable(false);
        txtHistorial.setWrapText(true);
        txtHistorial.setStyle("-fx-background-color: white; -fx-control-inner-background: #fafafa; " +
                "-fx-background-radius: 5px; -fx-border-radius: 5px; -fx-border-color: #bdc3c7; " +
                "-fx-border-width: 1px; -fx-font-family: 'Monaco', 'Consolas', 'monospace'; " +
                "-fx-font-size: 12px;");
    }

    // [MANTENER TODOS LOS MÉTODOS DE CONFIGURACIÓN - configurarBotonesAccion, etc.]
    private void configurarBotonesAccion() {
        // [MISMO CÓDIGO QUE ANTES]
    }

    private void configurarCampoApuesta() {
        // [MISMO CÓDIGO QUE ANTES]
    }

    private void configurarEventos() {
        txtApuesta.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*\\.?\\d*")) {
                txtApuesta.setText(oldValue);
            }
        });
    }

    private void inicializarJugador() {
        if (estadisticasJugador != null) {
            jugador = new Jugador(estadisticasJugador.getNombreJugador(), estadisticasJugador.getDineroActual());
            LOGGER.info("🎮 Jugador inicializado: " + estadisticasJugador.getNombreJugador() +
                    " con saldo: $" + estadisticasJugador.getDineroActual());
        } else {
            jugador = new Jugador("Jugador", 1000.0);
            LOGGER.warning("⚠️ Estadísticas de jugador no disponibles, usando valores por defecto");
        }
    }

    private void inicializarServicioJuego() {
        blackjackService = new BlackjackService(jugador, baseDatosService);
        try {
            blackjackService.iniciarNuevoJuego();
            agregarHistorial("¡Bienvenido " + jugador.getNombre() + "!");

            // *** CORRECCIÓN BUG 2: Verificar estado de la base de datos ***
            try {
                baseDatosService.verificarEstadoBaseDatos();
            } catch (Exception e) {
                LOGGER.warning("Error al verificar estado de BD: " + e.getMessage());
            }

        } catch (JuegoException e) {
            LOGGER.log(Level.SEVERE, "Error al inicializar servicio de juego", e);
            mostrarMensajeError("Error al inicializar el juego");
        }
    }

    @FXML
    private void onApostar() {
        try {
            String textoApuesta = txtApuesta.getText().trim();
            if (textoApuesta.isEmpty()) {
                mostrarMensaje("Ingresa una cantidad para apostar", false);
                return;
            }

            double cantidad = Double.parseDouble(textoApuesta);

            if (cantidad < 10) {
                mostrarMensaje("La apuesta mínima es $10", false);
                return;
            }

            if (cantidad > jugador.getSaldo()) {
                mostrarMensaje("Saldo insuficiente", false);
                return;
            }

            blackjackService.realizarApuesta(cantidad);
            agregarHistorial(String.format("Apuesta realizada: $%.2f", cantidad));

            actualizarInterfaz();

            // Si el juego no terminó inmediatamente (blackjack natural), habilitar acciones
            if (blackjackService.getEstadoJuego() == EstadoJuego.TURNO_JUGADOR) {
                habilitarBotonesAccion();
            } else if (blackjackService.getEstadoJuego() == EstadoJuego.JUEGO_TERMINADO) {
                procesarFinDelJuego();
            }

        } catch (NumberFormatException e) {
            mostrarMensaje("Ingresa un número válido", false);
        } catch (SaldoInsuficienteException e) {
            mostrarMensaje("Saldo insuficiente para esta apuesta", false);
        } catch (JuegoException e) {
            mostrarMensajeError("Error al realizar apuesta: " + e.getMessage());
        }
    }

    @FXML
    private void onPedir() {
        realizarAccionJuego(AccionJuego.PEDIR_CARTA, "Pidió carta");
    }

    @FXML
    private void onPlantarse() {
        realizarAccionJuego(AccionJuego.PLANTARSE, "Se plantó");

        if (blackjackService.getEstadoJuego() == EstadoJuego.TURNO_DEALER) {
            procesarTurnoDealer();
        }
    }

    @FXML
    private void onDoblar() {
        realizarAccionJuego(AccionJuego.DOBLAR, "Dobló la apuesta");

        if (blackjackService.getEstadoJuego() == EstadoJuego.TURNO_DEALER) {
            procesarTurnoDealer();
        }
    }

    @FXML
    private void onDividir() {
        realizarAccionJuego(AccionJuego.DIVIDIR, "Dividió las cartas");
    }

    @FXML
    private void onRendirse() {
        realizarAccionJuego(AccionJuego.RENDIRSE, "Se rindió");

        // *** CORRECCIÓN BUG 2: Guardar rendición correctamente ***
        try {
            LOGGER.info("🏳️ Guardando rendición...");
            baseDatosService.guardarResultadoPartida("rendida");

            // Actualizar estadísticas del jugador
            if (estadisticasJugador != null) {
                estadisticasJugador = baseDatosService.obtenerJugadorActual();
            }
        } catch (BaseDatosException e) {
            LOGGER.warning("Error al guardar rendición: " + e.getMessage());
        }

        procesarFinDelJuego();
    }

    private void realizarAccionJuego(AccionJuego accion, String mensajeHistorial) {
        try {
            blackjackService.realizarAccion(accion);
            agregarHistorial(mensajeHistorial);
            actualizarInterfaz();

            // Verificar si el jugador se pasó
            if (jugador.getManoActiva().estaPasado()) {
                agregarHistorial("¡Te pasaste!");
                if (!jugador.tieneMasManos()) {
                    procesarFinDelJuego();
                }
            }

        } catch (JuegoException e) {
            mostrarMensajeError("Error: " + e.getMessage());
        }
    }

    private void procesarTurnoDealer() {
        deshabilitarBotonesAccion();
        mostrarMensaje("Turno del dealer...", true);

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(1000), e -> {
                    try {
                        blackjackService.procesarTurnoDealer();
                        agregarHistorial("Dealer terminó su turno");
                        actualizarInterfaz();
                        procesarFinDelJuego();
                    } catch (JuegoException ex) {
                        mostrarMensajeError("Error en turno del dealer: " + ex.getMessage());
                    }
                })
        );
        timeline.play();
    }

    private void procesarFinDelJuego() {
        List<Mano> manosJugador = jugador.getManos();
        List<Double> apuestas = jugador.getApuestas();

        StringBuilder resultado = new StringBuilder("RESULTADO DEL JUEGO:\n");
        double gananciaTotal = 0;
        boolean algunaVictoria = false;
        boolean algunaDerrota = false;
        boolean algunEmpate = false;

        for (int i = 0; i < manosJugador.size(); i++) {
            Mano mano = manosJugador.get(i);
            double apuesta = apuestas.get(i);
            ResultadoMano resultadoMano = blackjackService.evaluarMano(mano);

            String mensajeMano = evaluarResultadoMano(resultadoMano, apuesta);
            resultado.append(String.format("Mano %d: %s\n", i + 1, mensajeMano));

            // Clasificar resultado para estadísticas
            switch (resultadoMano) {
                case JUGADOR_GANA:
                case DEALER_SE_PASA:
                case BLACKJACK_JUGADOR:
                    algunaVictoria = true;
                    gananciaTotal += (resultadoMano == ResultadoMano.BLACKJACK_JUGADOR) ? apuesta * 1.5 : apuesta;
                    break;
                case EMPATE:
                    algunEmpate = true;
                    break;
                default:
                    algunaDerrota = true;
                    gananciaTotal -= apuesta;
                    break;
            }
        }

        resultado.append(String.format("\nGanancia total: $%.2f", gananciaTotal));
        agregarHistorial(resultado.toString());

        // *** CORRECCIÓN BUG 2: Mejorar actualización de estadísticas ***
        actualizarEstadisticasJugador(algunaVictoria, algunaDerrota, algunEmpate);

        blackjackService.finalizarJuego();
        habilitarNuevoJuego();
        actualizarInterfaz();

        // Verificar Game Over
        verificarGameOver();
    }

    private void actualizarEstadisticasJugador(boolean algunaVictoria, boolean algunaDerrota, boolean algunEmpate) {
        if (estadisticasJugador != null) {
            try {
                LOGGER.info("📊 Actualizando estadísticas del jugador...");

                // Actualizar saldo actual
                estadisticasJugador.setDineroActual(jugador.getSaldo());

                // *** CORRECCIÓN BUG 2: Lógica mejorada para determinar resultado principal ***
                String tipoResultado = determinarResultadoPrincipal(algunaVictoria, algunaDerrota, algunEmpate);

                LOGGER.info("📊 Tipo de resultado determinado: " + tipoResultado);

                // Guardar resultado en base de datos
                baseDatosService.guardarResultadoPartida(tipoResultado);

                // Recargar estadísticas actualizadas desde la base de datos
                estadisticasJugador = baseDatosService.obtenerJugadorActual();

                LOGGER.info("📊 Estadísticas actualizadas: " + estadisticasJugador.toString());

            } catch (BaseDatosException e) {
                LOGGER.log(Level.SEVERE, "Error al actualizar estadísticas", e);
                mostrarMensajeError("Error al guardar estadísticas: " + e.getMessage());
            }
        } else {
            LOGGER.warning("⚠️ No hay estadísticas de jugador para actualizar");
        }
    }

    private String determinarResultadoPrincipal(boolean algunaVictoria, boolean algunaDerrota, boolean algunEmpate) {
        // Lógica simplificada y clara
        if (algunaVictoria && !algunaDerrota) {
            return "ganada";
        } else if (algunaDerrota && !algunaVictoria) {
            return "perdida";
        } else if (algunEmpate && !algunaVictoria && !algunaDerrota) {
            return "empate";
        } else if (algunaVictoria && algunaDerrota) {
            // Resultado mixto - contar como ganada si hay al menos una victoria
            return "ganada";
        } else {
            // Caso por defecto
            return "perdida";
        }
    }

    private void verificarGameOver() {
        if (jugador.getSaldo() < 10) {
            Platform.runLater(() -> {
                Timeline delayTimeline = new Timeline(
                        new KeyFrame(Duration.seconds(2), e -> {
                            Stage currentStage = (Stage) btnVolver.getScene().getWindow();
                            currentStage.close();

                            // Llamar al Game Over en el MenuController
                            if (menuController != null) {
                                menuController.mostrarGameOver();
                            }
                        })
                );
                delayTimeline.play();
            });
        }
    }

    private String evaluarResultadoMano(ResultadoMano resultado, double apuesta) {
        switch (resultado) {
            case JUGADOR_GANA:
                return String.format("¡GANASTE! +$%.2f", apuesta);
            case DEALER_GANA:
                return String.format("Perdiste -$%.2f", apuesta);
            case EMPATE:
                return "Empate (apuesta devuelta)";
            case BLACKJACK_JUGADOR:
                return String.format("¡BLACKJACK! +$%.2f", apuesta * 1.5);
            case BLACKJACK_DEALER:
                return String.format("Blackjack del dealer -$%.2f", apuesta);
            case JUGADOR_SE_PASA:
                return String.format("Te pasaste -$%.2f", apuesta);
            case DEALER_SE_PASA:
                return String.format("Dealer se pasó +$%.2f", apuesta);
            default:
                return "Resultado desconocido";
        }
    }

    @FXML
    private void onNuevoJuego() {
        try {
            // *** CORRECCIÓN BUG 1: Asegurar limpieza completa antes de nuevo juego ***
            LOGGER.info("🔄 Iniciando nuevo juego - Limpiando estado anterior");

            blackjackService.iniciarNuevoJuego();
            txtApuesta.setText("");
            agregarHistorial("\n--- NUEVO JUEGO ---");

            // Verificar que las manos estén limpias
            if (jugador.getManoActiva().cantidadCartas() > 0) {
                LOGGER.warning("⚠️ Las manos no se limpiaron correctamente en nuevo juego");
                agregarHistorial("⚠️ Advertencia: Limpiando cartas residuales...");
            }

            btnApostar.setDisable(false);
            txtApuesta.setDisable(false);
            btnNuevoJuego.setDisable(true);
            deshabilitarBotonesAccion();

            actualizarInterfaz();

        } catch (JuegoException e) {
            mostrarMensajeError("Error al iniciar nuevo juego: " + e.getMessage());
        }
    }

    @FXML
    private void onVolver() {
        // Guardar estado del jugador antes de cerrar
        if (estadisticasJugador != null) {
            try {
                estadisticasJugador.setDineroActual(jugador.getSaldo());
                baseDatosService.actualizarJugador(estadisticasJugador);
                LOGGER.info("💾 Estado del jugador guardado antes de cerrar");
            } catch (BaseDatosException e) {
                LOGGER.log(Level.WARNING, "Error al guardar estado del jugador", e);
            }
        }

        Stage stage = (Stage) btnVolver.getScene().getWindow();
        stage.close();
    }

    // [MANTENER TODOS LOS DEMÁS MÉTODOS IGUAL QUE ANTES]
    // actualizarInterfaz(), actualizarCartasDealer(), etc.

    private void actualizarInterfaz() {
        // Actualizar información del jugador
        lblSaldoJugador.setText(String.format("Saldo: $%.2f", jugador.getSaldo()));

        if (blackjackService.getEstadoJuego() != EstadoJuego.ESPERANDO_APUESTA) {
            lblApuestaActual.setText(String.format("Apuesta: $%.2f", jugador.getApuestaActiva()));
        } else {
            lblApuestaActual.setText("Apuesta: $0.00");
        }

        // Actualizar cartas del dealer
        actualizarCartasDealer();

        // Actualizar cartas del jugador
        actualizarCartasJugador();

        // Actualizar botones según el estado del juego
        actualizarEstadoBotones();

        // Actualizar estado del juego
        actualizarEstadoJuego();
    }

    private void actualizarCartasDealer() {
        Dealer dealer = blackjackService.getDealer();
        lblCartasDealer.setText("Dealer: " + dealer.toString());
        lblCartasDealer.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: normal;");

        if (dealer.isCartaOcultaVisible()) {
            lblValorDealer.setText(String.format("Valor: %d", dealer.getMano().getValor()));

            if (dealer.getMano().estaPasado()) {
                lblValorDealer.setStyle("-fx-text-fill: #ffebee; -fx-font-size: 12px; -fx-font-weight: bold; " +
                        "-fx-effect: dropshadow(three-pass-box, rgba(244,67,54,0.8), 2, 0, 0, 0);");
            } else if (dealer.getMano().esBlackjack()) {
                lblValorDealer.setStyle("-fx-text-fill: #fff3e0; -fx-font-size: 12px; -fx-font-weight: bold; " +
                        "-fx-effect: dropshadow(three-pass-box, rgba(255,193,7,0.8), 2, 0, 0, 0);");
            } else {
                lblValorDealer.setStyle("-fx-text-fill: white; -fx-font-size: 12px; -fx-font-weight: bold;");
            }
        } else {
            lblValorDealer.setText(String.format("Valor visible: %d", dealer.getValorVisible()));
            lblValorDealer.setStyle("-fx-text-fill: white; -fx-font-size: 12px; -fx-font-weight: bold;");
        }
    }

    private void actualizarCartasJugador() {
        Mano manoActiva = jugador.getManoActiva();
        lblCartasJugador.setText("Tus cartas: " + manoActiva.toString());
        lblCartasJugador.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: normal;");

        lblValorJugador.setText(String.format("Valor: %d", manoActiva.getValor()));

        // Colorear según el valor
        if (manoActiva.estaPasado()) {
            lblValorJugador.setStyle("-fx-text-fill: #ffebee; -fx-font-size: 12px; -fx-font-weight: bold; " +
                    "-fx-effect: dropshadow(three-pass-box, rgba(244,67,54,0.8), 2, 0, 0, 0);");
        } else if (manoActiva.esBlackjack()) {
            lblValorJugador.setStyle("-fx-text-fill: #fff3e0; -fx-font-size: 12px; -fx-font-weight: bold; " +
                    "-fx-effect: dropshadow(three-pass-box, rgba(255,193,7,0.8), 2, 0, 0, 0);");
        } else if (manoActiva.getValor() == 21) {
            lblValorJugador.setStyle("-fx-text-fill: #e8f5e8; -fx-font-size: 12px; -fx-font-weight: bold; " +
                    "-fx-effect: dropshadow(three-pass-box, rgba(76,175,80,0.8), 2, 0, 0, 0);");
        } else {
            lblValorJugador.setStyle("-fx-text-fill: white; -fx-font-size: 12px; -fx-font-weight: bold;");
        }

        // Si hay múltiples manos, mostrar información
        if (jugador.getManos().size() > 1) {
            String infoManos = String.format("Mano %d de %d",
                    jugador.getManoActivaIndex() + 1, jugador.getManos().size());
            lblCartasJugador.setText(lblCartasJugador.getText() + " (" + infoManos + ")");
        }
    }

    // [MANTENER RESTO DE MÉTODOS IGUAL QUE ANTES]
    private void actualizarEstadoBotones() {
        EstadoJuego estado = blackjackService.getEstadoJuego();

        switch (estado) {
            case ESPERANDO_APUESTA:
                btnApostar.setDisable(false);
                txtApuesta.setDisable(false);
                deshabilitarBotonesAccion();
                btnNuevoJuego.setDisable(true);
                break;

            case TURNO_JUGADOR:
                btnApostar.setDisable(true);
                txtApuesta.setDisable(true);
                habilitarBotonesAccion();
                btnNuevoJuego.setDisable(true);
                break;

            case TURNO_DEALER:
            case JUEGO_TERMINADO:
                btnApostar.setDisable(true);
                txtApuesta.setDisable(true);
                deshabilitarBotonesAccion();
                break;
        }
    }

    private void habilitarBotonesAccion() {
        btnPedir.setDisable(!blackjackService.puedeRealizarAccion(AccionJuego.PEDIR_CARTA));
        btnPlantarse.setDisable(!blackjackService.puedeRealizarAccion(AccionJuego.PLANTARSE));
        btnDoblar.setDisable(!blackjackService.puedeRealizarAccion(AccionJuego.DOBLAR));
        btnDividir.setDisable(!blackjackService.puedeRealizarAccion(AccionJuego.DIVIDIR));
        btnRendirse.setDisable(!blackjackService.puedeRealizarAccion(AccionJuego.RENDIRSE));
    }

    private void deshabilitarBotonesAccion() {
        btnPedir.setDisable(true);
        btnPlantarse.setDisable(true);
        btnDoblar.setDisable(true);
        btnDividir.setDisable(true);
        btnRendirse.setDisable(true);
    }

    private void habilitarNuevoJuego() {
        btnNuevoJuego.setDisable(false);
    }

    private void actualizarEstadoJuego() {
        EstadoJuego estado = blackjackService.getEstadoJuego();
        String textoEstado;

        switch (estado) {
            case ESPERANDO_APUESTA:
                textoEstado = "Realiza tu apuesta para comenzar";
                break;
            case REPARTIENDO:
                textoEstado = "Repartiendo cartas...";
                break;
            case TURNO_JUGADOR:
                textoEstado = "Tu turno - Elige una acción";
                break;
            case TURNO_DEALER:
                textoEstado = "Turno del dealer";
                break;
            case JUEGO_TERMINADO:
                textoEstado = "Juego terminado";
                break;
            default:
                textoEstado = "Estado desconocido";
        }

        lblEstadoJuego.setText(textoEstado);
    }

    private void mostrarMensaje(String mensaje, boolean esInfo) {
        lblMensaje.setText(mensaje);
        if (esInfo) {
            lblMensaje.setStyle("-fx-text-fill: #3498db; -fx-font-weight: bold; -fx-font-size: 14px;");
        } else {
            lblMensaje.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold; -fx-font-size: 14px; " +
                    "-fx-effect: dropshadow(three-pass-box, rgba(231,76,60,0.3), 2, 0, 0, 0);");
        }

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(3), e -> {
                    lblMensaje.setText("");
                    lblMensaje.setStyle("");
                })
        );
        timeline.play();
    }

    private void mostrarMensajeError(String mensaje) {
        mostrarMensaje(mensaje, false);
        LOGGER.warning("Error mostrado al usuario: " + mensaje);
    }

    private void agregarHistorial(String mensaje) {
        Platform.runLater(() -> {
            txtHistorial.appendText(mensaje + "\n");
            txtHistorial.setScrollTop(Double.MAX_VALUE);
        });
    }
}