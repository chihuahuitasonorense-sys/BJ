// BarajaVaciaException.java
package com.blackjack.bj.exception;

public class BarajaVaciaException extends JuegoException {
    public BarajaVaciaException() {
        super("No quedan cartas en la baraja");
    }
}