// SaldoInsuficienteException.java
package com.blackjack.bj.exception;

public class SaldoInsuficienteException extends JuegoException {
    public SaldoInsuficienteException(double saldoActual, double apuestaIntentada) {
        super(String.format("Saldo insuficiente. Saldo actual: %.2f, Apuesta intentada: %.2f",
                saldoActual, apuestaIntentada));
    }
}