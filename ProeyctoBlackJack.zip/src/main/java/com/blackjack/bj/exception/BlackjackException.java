// BlackjackException.java
package com.blackjack.bj.exception;

public class BlackjackException extends Exception {
    public BlackjackException(String mensaje) {
        super(mensaje);
    }

    public BlackjackException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}