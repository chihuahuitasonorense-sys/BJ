// BaseDatosException.java
package com.blackjack.bj.exception;

public class BaseDatosException extends BlackjackException {
    public BaseDatosException(String mensaje) {
        super("Error en base de datos: " + mensaje);
    }

    public BaseDatosException(String mensaje, Throwable causa) {
        super("Error en base de datos: " + mensaje, causa);
    }
}
