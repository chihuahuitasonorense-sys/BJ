// JuegoException.java
package com.blackjack.bj.exception;

public class JuegoException extends BlackjackException {
    public JuegoException(String mensaje) {
        super("Error en el juego: " + mensaje);
    }
}