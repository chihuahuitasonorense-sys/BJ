module com.blackjack.bj {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;
    requires java.logging;

    // Permitir acceso a SQLite
    requires org.xerial.sqlitejdbc;

    exports com.blackjack.bj;
    exports com.blackjack.bj.controller;
    exports com.blackjack.bj.model;
    exports com.blackjack.bj.service;
    exports com.blackjack.bj.exception;

    // Abrir paquetes para reflection (necesario para JavaFX FXML)
    opens com.blackjack.bj to javafx.fxml;
    opens com.blackjack.bj.controller to javafx.fxml;
    opens com.blackjack.bj.model to javafx.base;
}